import { Injectable, NotFoundException } from "@nestjs/common";
import { PrismaService } from "../prisma/prisma.service";
import {
  Project,
  Page,
  Component,
  Widget,
  Template,
  WidgetInstance,
  ComponentInstance,
} from "@prisma/client";

/** Supported models for dynamic relationship mapping */
type PrismaModels = {
  project: Project;
  page: Page;
  component: Component;
  widget: Widget;
  template: Template;
  widgetInstance: WidgetInstance;
  componentInstance: ComponentInstance;
};

export type SupportedModel = keyof PrismaModels;

type PrismaAccessors = {
  [K in SupportedModel]: {
    findUnique: (args: {
      where: { id: number };
    }) => Promise<PrismaModels[K] | null>;
    update: (args: {
      where: { id: number };
      data: any;
    }) => Promise<PrismaModels[K]>;
  };
};

@Injectable()
export class RelationshipService {
  private readonly modelMap: PrismaAccessors;

  constructor(private readonly prisma: PrismaService) {
    this.modelMap = {
      project: {
        findUnique: (args) => this.prisma.project.findUnique(args),
        update: (args) => this.prisma.project.update(args),
      },
      page: {
        findUnique: (args) => this.prisma.page.findUnique(args),
        update: (args) => this.prisma.page.update(args),
      },
      component: {
        findUnique: (args) => this.prisma.component.findUnique(args),
        update: (args) => this.prisma.component.update(args),
      },
      widget: {
        findUnique: (args) => this.prisma.widget.findUnique(args),
        update: (args) => this.prisma.widget.update(args),
      },
      template: {
        findUnique: (args) => this.prisma.template.findUnique(args),
        update: (args) => this.prisma.template.update(args),
      },
      widgetInstance: {
        findUnique: (args) => this.prisma.widgetInstance.findUnique(args),
        update: (args) => this.prisma.widgetInstance.update(args),
      },
      componentInstance: {
        findUnique: (args) => this.prisma.componentInstance.findUnique(args),
        update: (args) => this.prisma.componentInstance.update(args),
      },
    };
  }

  private getForeignKeyField(sourceModel: SupportedModel): string {
    return `${sourceModel}Id`;
  }

  async linkEntities(
    sourceModel: SupportedModel,
    sourceId: number,
    targetModel: SupportedModel,
    targetId: number,
  ) {
    const source = await this.modelMap[sourceModel].findUnique({
      where: { id: sourceId },
    });
    const target = await this.modelMap[targetModel].findUnique({
      where: { id: targetId },
    });

    if (!source || !target) {
      throw new NotFoundException(`${sourceModel} or ${targetModel} not found`);
    }

    const foreignKeyField = this.getForeignKeyField(sourceModel);

    return this.modelMap[targetModel].update({
      where: { id: targetId },
      data: { [foreignKeyField]: sourceId },
    });
  }

  async bulkLinkToSource(
    sourceModel: SupportedModel,
    sourceId: number,
    targetModel: SupportedModel,
    targetIds: number[],
  ) {
    const source = await this.modelMap[sourceModel].findUnique({
      where: { id: sourceId },
    });
    if (!source) throw new NotFoundException(`${sourceModel} not found`);

    const foreignKeyField = this.getForeignKeyField(sourceModel);

    return Promise.all(
      targetIds.map((targetId) =>
        this.modelMap[targetModel].update({
          where: { id: targetId },
          data: { [foreignKeyField]: sourceId },
        }),
      ),
    );
  }

  async linkToSource(
    sourceModel: SupportedModel,
    sourceId: number,
    links: { targetModel: SupportedModel; targetId: number }[],
  ) {
    const source = await this.modelMap[sourceModel].findUnique({
      where: { id: sourceId },
    });
    if (!source) throw new NotFoundException(`${sourceModel} not found`);

    const foreignKeyField = this.getForeignKeyField(sourceModel);

    return Promise.all(
      links.map(({ targetModel, targetId }) =>
        this.modelMap[targetModel].update({
          where: { id: targetId },
          data: { [foreignKeyField]: sourceId },
        }),
      ),
    );
  }
}
