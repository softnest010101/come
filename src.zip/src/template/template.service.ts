// template.service.ts - Service logic for Template
