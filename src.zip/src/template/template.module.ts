// template.module.ts - Module definition for Template
