// create-template.dto.ts - DTO for creating Template
