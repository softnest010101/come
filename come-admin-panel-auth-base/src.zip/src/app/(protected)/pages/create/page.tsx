"use client";

import PageHeader from "@/components/shared/PageHeader";
import PageCreateForm from "@/components/pages/PageCreateForm";
import { useRouter, useParams } from "next/navigation";

export default function CreatePagePage() {
  const router = useRouter();
  const params = useParams();
  const projectId = Number(params.projectId);

  const handleCreated = () => {
    router.push(`/projects/${projectId}/pages`);
  };

  if (!projectId)
    return <div className="p-4 text-red-500">Project ID missing</div>;

  return (
    <div className="p-8">
      <PageHeader
        title="➕ Create Page"
        backLink={`/projects/${projectId}/pages`}
      />
      <PageCreateForm projectId={projectId} onCreated={handleCreated} />
    </div>
  );
}
