// 📁 my-platform/come-admin-panel-auth-base/src/lib/api.ts

import axios from "axios";
import { useAuthStore } from "./useAuthStore";

const api = axios.create({
  baseURL: "http://localhost:3000/api", // ✅ აუცილებელია /api
  headers: {
    "Content-Type": "application/json",
  },
});

api.interceptors.request.use((config) => {
  const token = useAuthStore.getState().token;
  if (token) {
    config.headers = config.headers || {};
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export default api;

// ✅ Custom API Methods

export async function duplicateProject(projectId: number) {
  const response = await api.post(`/projects/${projectId}/duplicate`);
  return response.data;
}

export async function duplicatePage(pageId: number) {
  const response = await api.post(`/pages/${pageId}/duplicate`);
  return response.data;
}
