"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { toast } from "react-toastify";
import type { AxiosError } from "axios";
import api from "@/lib/api";

type PageEditFormProps = {
  id: number;
  initialData: {
    name: string;
    description?: string;
    [key: string]: unknown;
  };
};

export default function PageEditForm({ id, initialData }: PageEditFormProps) {
  const [name, setName] = useState(initialData.name);
  const [description, setDescription] = useState(initialData.description ?? "");
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const handleUpdate = async () => {
    if (!name.trim()) {
      toast.error("❌ Page name is required");
      return;
    }

    setLoading(true);
    try {
      await api.patch(`/pages/${id}`, {
        name,
        description,
      });

      toast.success("✅ Page updated successfully!");
      router.push("/pages");
    } catch (error: unknown) {
      const axiosErr = error as AxiosError<{ message?: string }>;
      const message =
        axiosErr.response?.data?.message ?? "❌ Failed to update page";
      toast.error(message);
      console.error("❌ Update error:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = () => {
    router.push("/pages");
  };

  return (
    <div className="space-y-4">
      <input
        type="text"
        value={name}
        onChange={(e) => setName(e.target.value)}
        placeholder="Page Name"
        className="p-2 border rounded w-full"
        disabled={loading}
      />

      <textarea
        value={description}
        onChange={(e) => setDescription(e.target.value)}
        placeholder="Description (optional)"
        className="p-2 border rounded w-full"
        rows={3}
        disabled={loading}
      />

      <div className="flex gap-4">
        <button
          onClick={handleUpdate}
          disabled={loading}
          className="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 disabled:opacity-50"
        >
          {loading ? "Saving..." : "Save Changes"}
        </button>

        <button
          onClick={handleCancel}
          disabled={loading}
          className="bg-gray-300 text-gray-800 px-4 py-2 rounded hover:bg-gray-400 disabled:opacity-50"
        >
          Cancel
        </button>
      </div>
    </div>
  );
}
