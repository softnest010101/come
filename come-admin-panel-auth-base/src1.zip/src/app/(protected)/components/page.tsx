// 📁 /components/page.tsx

import ComponentList from "@/components/components/ComponentList";
import { useEffect, useState } from "react";
import api from "@/lib/api";

type Component = Record<string, unknown>;

export default function ComponentsPage() {
  const [components, setComponents] = useState<Component[]>([]);

  useEffect(() => {
    api.get("/components/my").then((res) => setComponents(res.data));
  }, []);

  const handleDelete = async (id: number) => {
    await api.delete(`/components/${id}`);
    setComponents((prev) => prev.filter((c) => c.id !== id));
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4 text-[#5b4636]">📦 My Components</h1>
      <ComponentList components={components} onDelete={handleDelete} />
    </div>
  );
}
