// 📁 /components/edit/[id]/page.tsx

import ComponentEditForm from "@/components/components/ComponentEditForm";

type Props = {
  params: {
    id: string;
  };
};

export default function EditComponentPage({ params }: Props) {
  const componentId = Number(params.id);

  return (
    <div className="max-w-2xl mx-auto p-6">
      <h1 className="text-2xl font-bold mb-4 text-[#5b4636]">✏️ Edit Component</h1>
      <ComponentEditForm componentId={componentId} />
    </div>
  );
}
