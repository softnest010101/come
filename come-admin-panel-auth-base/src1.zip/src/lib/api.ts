// 📁 src/lib/api.ts
import axios from "axios";
import { useAuthStore } from "./useAuthStore";

const api = axios.create({
  baseURL: "http://localhost:3000/api",
  headers: {
    "Content-Type": "application/json",
  },
});

api.interceptors.request.use((config) => {
  const token = useAuthStore.getState().token;
  if (token) {
    config.headers = config.headers || {};
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export default api;

// ✅ Duplicates (for each module)
export async function duplicateProject(id: number) {
  const res = await api.post(`/projects/${id}/duplicate`);
  return res.data;
}

export async function duplicatePage(id: number) {
  const res = await api.post(`/pages/${id}/duplicate`);
  return res.data;
}

export async function duplicateComponent(id: number) {
  const res = await api.post(`/components/${id}/duplicate`);
  return res.data;
}

export async function duplicateWidget(id: number) {
  const res = await api.post(`/widgets/${id}/duplicate`);
  return res.data;
}

export async function duplicateTemplate(id: number) {
  const res = await api.post(`/templates/${id}/duplicate`);
  return res.data;
}

export async function duplicateWidgetInstance(id: number) {
  const res = await api.post(`/widget-instances/${id}/duplicate`);
  return res.data;
}

export async function duplicateComponentInstance(id: number) {
  const res = await api.post(`/component-instances/${id}/duplicate`);
  return res.data;
}

// ✅ Universal Link Function (Single link)
export async function linkModelToModel(
  sourceModel: string,
  sourceId: number,
  targetModel: string,
  targetId: number
) {
  const res = await api.post(
    `/${sourceModel}s/${sourceId}/link/${targetModel}/${targetId}`
  );
  return res.data;
}

// ✅ Bulk Link Function (Multiple targets)
export async function bulkLinkToModel(
  sourceModel: string,
  sourceId: number,
  targetModel: string,
  targetIds: number[]
) {
  const res = await api.post(`/${sourceModel}s/${sourceId}/bulk-link`, {
    targetModel,
    targetIds,
  });
  return res.data;
}

// ✅ Create Component
export interface CreateComponentInput {
  name: string;
  description?: string;
  pageId?: number;
  config?: object;
}

export async function createComponent(data: CreateComponentInput) {
  const res = await api.post("/components", data);
  return res.data;
}
