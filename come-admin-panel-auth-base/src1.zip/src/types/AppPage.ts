export interface AppPageBase {
  id: number;
  name: string;
  description?: string;
  createdAt?: string;
  updatedAt?: string;
  visible?: boolean;
  project?: {
    id: number;
    name: string;
  };
}

export type AppPage = AppPageBase & {
  [key: string]: unknown;
};
export type Page = {
  id: number;
  name: string;
  visible: boolean;
};
