"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { toast } from "react-toastify";
import type { AxiosError } from "axios";
import api from "@/lib/api";

type Props = {
  onCreated?: () => void;
  projectId: number;
};

export default function PageCreateForm({ onCreated, projectId }: Props) {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const handleCreate = async () => {
    if (!name.trim()) {
      toast.error("❌ Page name is required");
      return;
    }

    setLoading(true);
    try {
      await api.post("/pages", {
        name,
        description,
        projectId,
      });

      toast.success("✅ Page created successfully!");
      setName("");
      setDescription("");

      if (onCreated) onCreated();
      else router.push("/pages");
    } catch (error: unknown) {
      const axiosError = error as AxiosError<{ message?: string }>;
      toast.error(
        axiosError.response?.data?.message ?? "❌ Failed to create page",
      );
      console.error("❌ Create error:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <input
        type="text"
        placeholder="Page Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
        className="p-2 border rounded w-full"
        disabled={loading}
      />
      <textarea
        placeholder="Description (optional)"
        value={description}
        onChange={(e) => setDescription(e.target.value)}
        className="p-2 border rounded w-full"
        rows={3}
        disabled={loading}
      />
      <button
        onClick={handleCreate}
        disabled={loading}
        className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 disabled:bg-gray-300"
      >
        {loading ? "Creating..." : "Create Page"}
      </button>
    </div>
  );
}
