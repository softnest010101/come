'use client';

import { useRouter } from 'next/navigation';

type EntityPageHeaderProps = {
  entityName: string;
};

export default function EntityPageHeader({ entityName }: EntityPageHeaderProps) {
  const router = useRouter();

  const handleCreateClick = () => {
    router.push(`/admin/entities/${entityName.toLowerCase()}/create`);
  };

  return (
    <div className="flex items-center justify-between mb-6">
      <h1 className="text-2xl font-bold capitalize">{entityName}</h1>
      <button
        onClick={handleCreateClick}
        className="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded"
      >
        ➕ Create New {entityName}
      </button>
    </div>
  );
}
