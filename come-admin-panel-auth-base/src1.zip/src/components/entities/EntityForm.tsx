'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import api from '@/lib/api';

type EntityFormProps = {
  entityName: string;
  mode: 'create' | 'edit';
  initialData?: Record<string, any>;
  id?: number;
};

export default function EntityForm({
  entityName,
  mode,
  initialData,
  id,
}: EntityFormProps) {
  const router = useRouter();
  const [formData, setFormData] = useState<Record<string, any>>(initialData || {});
  const [loading, setLoading] = useState(mode === 'edit' && !initialData);

  useEffect(() => {
    if (mode === 'edit' && id && !initialData) {
      api.get(`/assistant/entity/${entityName}/${id}`).then((res) => {
        setFormData(res.data);
        setLoading(false);
      });
    }
  }, [id, entityName, mode, initialData]);

  const handleChange = (key: string, value: any) => {
    setFormData((prev) => ({ ...prev, [key]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      if (mode === 'create') {
        await api.post(`/assistant/entity/${entityName}`, formData);
        alert('✅ Created successfully!');
      } else if (mode === 'edit' && id) {
        await api.patch(`/assistant/entity/${entityName}/${id}`, formData);
        alert('✅ Updated successfully!');
      }
      router.push(`/admin/entities`);
    } catch (error) {
      console.error('❌ Form error:', error);
      alert('Failed to submit form.');
    }
  };

  if (loading) return <div className="p-6">Loading...</div>;

  return (
    <form
      onSubmit={handleSubmit}
      className="max-w-2xl mx-auto p-6 bg-white rounded shadow space-y-4"
    >
      {Object.keys(formData).map((key) =>
        key === 'id' ? null : (
          <div key={key} className="flex flex-col">
            <label className="font-semibold capitalize">{key}</label>
            <input
              type="text"
              value={formData[key] ?? ''}
              onChange={(e) => handleChange(key, e.target.value)}
              className="border rounded px-3 py-2 mt-1"
            />
          </div>
        ),
      )}

      <button
        type="submit"
        className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded w-full"
      >
        {mode === 'create' ? 'Create' : 'Update'}
      </button>
    </form>
  );
}
