'use client';

import { useEffect, useState } from 'react';
import api from '@/lib/api';
import Link from 'next/link';

type EntityRecord = Record<string, any>;

interface EntityListProps {
  entityName: string;
}

export default function EntityList({ entityName }: EntityListProps) {
  const [records, setRecords] = useState<EntityRecord[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchData() {
      try {
        const res = await api.get(`/assistant/entity/${entityName}`);
        setRecords(res.data);
      } catch (error) {
        console.error('❌ Failed to fetch entities:', error);
      } finally {
        setLoading(false);
      }
    }
    fetchData();
  }, [entityName]);

  const handleDelete = async (id: number) => {
    if (!confirm('Are you sure you want to delete this record?')) return;

    try {
      await api.delete(`/assistant/entity/${entityName}/${id}`);
      setRecords((prev) => prev.filter((rec) => rec.id !== id));
    } catch (error) {
      console.error('❌ Failed to delete record:', error);
    }
  };

  if (loading) return <div className="p-6">Loading {entityName}...</div>;

  if (!records.length) return <div className="p-6">No records found.</div>;

  return (
    <div className="p-6">
      <h2 className="text-xl font-semibold mb-4">{entityName?.toUpperCase()} List</h2>
      <table className="w-full text-sm border border-gray-300">
        <thead>
          <tr className="bg-gray-100">
            {Object.keys(records[0]).map((key) => (
              <th key={key} className="text-left px-2 py-1 border">
                {key}
              </th>
            ))}
            <th className="px-2 py-1 border">Actions</th>
          </tr>
        </thead>
        <tbody>
          {records.map((record) => (
            <tr key={record.id} className="hover:bg-gray-50">
              {Object.entries(record).map(([key, value]) => (
                <td key={key} className="px-2 py-1 border truncate max-w-xs">
                  {typeof value === 'object' ? JSON.stringify(value) : String(value)}
                </td>
              ))}
              <td className="px-2 py-1 border space-x-2">
                <Link
                  href={`/admin/entities/${entityName}/edit/${record.id}`}
                  className="text-blue-600 hover:underline"
                >
                  Edit
                </Link>
                <button
                  onClick={() => handleDelete(record.id)}
                  className="text-red-600 hover:underline"
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
