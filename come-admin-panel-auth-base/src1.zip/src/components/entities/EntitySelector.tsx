'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import api from '@/lib/api';

export default function EntitySelector() {
  const [entities, setEntities] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchEntities() {
      try {
        const res = await api.get('/assistant/entities');
        setEntities(res.data);
      } catch (error) {
        console.error('❌ Failed to fetch entity list:', error);
      } finally {
        setLoading(false);
      }
    }

    fetchEntities();
  }, []);

  if (loading) return <div className="p-6">Loading available entities...</div>;

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Entity Manager</h1>
      <ul className="space-y-2">
        {entities.map((entity) => (
          <li key={entity}>
            <Link
              href={`/admin/entities/${entity}`}
              className="text-blue-600 hover:underline"
            >
              ➤ {entity}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
