"use client";

import { useEffect, useState } from "react";
import { toast } from "react-toastify";
import { duplicateComponent } from "@/lib/api";
import UniversalLinkModal from "@/components/shared/UniversalLinkModal";

type ComponentEditFormProps = {
  componentId: number;
};

export default function ComponentEditForm({ componentId }: ComponentEditFormProps) {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [pageId, setPageId] = useState<number | null>(null);
  const [config, setConfig] = useState("{}");
  const [loading, setLoading] = useState(true);
  const [showLinkModal, setShowLinkModal] = useState(false);

  useEffect(() => {
    const fetchComponent = async () => {
      try {
        const res = await fetch(`/api/components/${componentId}`);
        const component = await res.json();
        setName(component.name);
        setDescription(component.description ?? "");
        setPageId(component.pageId ?? null);
        setConfig(JSON.stringify(component.config ?? {}, null, 2));
      } catch (err) {
        console.error(err);
        toast.error("❌ Failed to load component");
      } finally {
        setLoading(false);
      }
    };

    fetchComponent();
  }, [componentId]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      JSON.parse(config); // Validate JSON
      await duplicateComponent(componentId); // Placeholder for update logic
      toast.success("✅ Component updated");
      setShowLinkModal(true); // Show linking modal
    } catch (err) {
      console.error(err);
      toast.error("❌ Failed to update component");
    }
  };

  if (loading) {
    return <p className="p-4">⏳ Loading component...</p>;
  }

  return (
    <>
      <form onSubmit={handleSubmit} className="space-y-4 p-4">
        <div>
          <label className="block mb-1 text-sm font-medium">Name</label>
          <input
            type="text"
            className="w-full border rounded px-3 py-2"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>

        <div>
          <label className="block mb-1 text-sm font-medium">Description</label>
          <textarea
            className="w-full border rounded px-3 py-2"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
          />
        </div>

        <div>
          <label className="block mb-1 text-sm font-medium">Page ID (optional)</label>
          <input
            type="number"
            className="w-full border rounded px-3 py-2"
            value={pageId ?? ""}
            onChange={(e) => setPageId(Number(e.target.value))}
          />
        </div>

        <div>
          <label className="block mb-1 text-sm font-medium">Config (JSON)</label>
          <textarea
            className="w-full border rounded px-3 py-2 font-mono"
            rows={4}
            value={config}
            onChange={(e) => setConfig(e.target.value)}
          />
        </div>

        <button
          type="submit"
          className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700"
        >
          💾 Update Component
        </button>
      </form>

      {showLinkModal && (
        <div className="mt-6">
          <UniversalLinkModal
            isOpen={true}
            sourceId={componentId}
            sourceModel="component"
            onClose={() => setShowLinkModal(false)}
            onSuccess={() => toast.success("🔗 Linked successfully")}
          />
        </div>
      )}
    </>
  );
}
