"use client";

import { useEffect, useState } from "react";
import { Dialog } from "@headlessui/react";
import { toast } from "react-toastify";
import api from "@/lib/api";

type ComponentLinkModalProps = {
  isOpen: boolean;
  sourceId: number;
  sourceModel: string;
  targetModel: string;
  onClose: () => void;
  onSuccess: () => void;
};

export default function ComponentLinkModal({
  isOpen,
  sourceId,
  sourceModel,
  targetModel,
  onClose,
  onSuccess,
}: ComponentLinkModalProps) {
  const [targetId, setTargetId] = useState<number | "">("");
  const [isLoading, setIsLoading] = useState(false);
  const [options, setOptions] = useState<{ id: number; name: string }[]>([]);

  useEffect(() => {
    if (targetModel === "page") {
      api
        .get("/pages/my")
        .then((res) => setOptions(res.data))
        .catch(() => toast.error("❌ Failed to load pages"));
    }
  }, [targetModel]);

  const handleLink = async () => {
    if (targetId === "" || isNaN(Number(targetId))) {
      toast.error("❌ Please select or enter a valid ID");
      return;
    }

    try {
      setIsLoading(true);
      await api.post(`/${sourceModel}s/${sourceId}/link/${targetModel}/${targetId}`);
      toast.success("✅ Linked successfully");
      onSuccess();
      onClose();
    } catch (err) {
      console.error(err);
      toast.error("❌ Linking failed");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onClose={onClose} className="fixed z-50 inset-0 flex items-center justify-center p-4 bg-black/50">
      <Dialog.Panel className="bg-white w-full max-w-md rounded-lg shadow-lg p-6">
        <Dialog.Title className="text-lg font-semibold text-[#4b3621] mb-4">
          🔗 Link {sourceModel} to {targetModel}
        </Dialog.Title>

        <div className="space-y-4">
          <div>
            <label className="block text-sm text-[#5b4636] mb-1">
              Target {targetModel} ID
            </label>

            {targetModel === "page" ? (
              <select
                value={targetId}
                onChange={(e) => setTargetId(Number(e.target.value))}
                className="w-full border rounded p-2 text-sm text-[#4b3621]"
              >
                <option value="">Select Page</option>
                {options.map((item) => (
                  <option key={item.id} value={item.id}>
                    {item.name || "Untitled"} (ID: {item.id})
                  </option>
                ))}
              </select>
            ) : (
              <input
                type="number"
                value={targetId}
                onChange={(e) => setTargetId(Number(e.target.value))}
                className="w-full border rounded p-2 text-sm text-[#4b3621]"
                placeholder="Enter ID"
              />
            )}
          </div>
        </div>

        <div className="mt-6 flex justify-end space-x-2">
          <button
            onClick={onClose}
            className="px-4 py-2 text-sm bg-gray-200 text-[#4b3621] rounded hover:bg-gray-300"
          >
            Cancel
          </button>
          <button
            onClick={handleLink}
            disabled={isLoading}
            className="px-4 py-2 text-sm bg-[#a67857] text-white rounded hover:bg-[#946548] disabled:opacity-50"
          >
            {isLoading ? "Linking..." : "Link"}
          </button>
        </div>
      </Dialog.Panel>
    </Dialog>
  );
}
