"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createComponent } from "@/lib/api"; // ✅ სახელით იმპორტი
import { toast } from "react-toastify";
import UniversalLinkModal from "@/components/shared/UniversalLinkModal"; // ✅ სწორი მოდალის იმპორტი

export default function ComponentCreateForm() {
  const router = useRouter();
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [pageId, setPageId] = useState<number | null>(null);
  const [config, setConfig] = useState("{}");
  const [newComponentId, setNewComponentId] = useState<number | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      const parsedConfig = config ? JSON.parse(config) : {};
      const created = await createComponent({
        name,
        description,
        pageId: pageId || undefined,
        config: parsedConfig,
      });
      toast.success("✅ Component created");
      setNewComponentId(created.id);
    } catch (err) {
      toast.error("❌ Failed to create component");
      console.error(err);
    }
  };

  return (
    <>
      <form onSubmit={handleSubmit} className="space-y-4 p-4">
        <div>
          <label className="block mb-1 text-sm font-medium">Name</label>
          <input
            type="text"
            className="w-full border rounded px-3 py-2"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>

        <div>
          <label className="block mb-1 text-sm font-medium">Description</label>
          <textarea
            className="w-full border rounded px-3 py-2"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
          />
        </div>

        <div>
          <label className="block mb-1 text-sm font-medium">Page ID (optional)</label>
          <input
            type="number"
            className="w-full border rounded px-3 py-2"
            value={pageId ?? ""}
            onChange={(e) => setPageId(Number(e.target.value))}
          />
        </div>

        <div>
          <label className="block mb-1 text-sm font-medium">Config (JSON)</label>
          <textarea
            className="w-full border rounded px-3 py-2 font-mono"
            rows={4}
            value={config}
            onChange={(e) => setConfig(e.target.value)}
          />
        </div>

        <button
          type="submit"
          className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
        >
          ➕ Create Component
        </button>
      </form>

      {newComponentId && (
        <UniversalLinkModal
          isOpen={true}
          sourceId={newComponentId}
          sourceModel="component"
          onClose={() => setNewComponentId(null)}
          onSuccess={() => {
            toast.success("🔗 Linked successfully");
            setNewComponentId(null);
            router.refresh();
          }}
        />
      )}
    </>
  );
}
