// update-template.dto.ts - DTO for updating Template
