// template.controller.ts - Controller logic for Template
