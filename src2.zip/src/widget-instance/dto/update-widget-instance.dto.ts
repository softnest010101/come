// ✅ my-platform/src/widget-instance/dto/update-widget-instance.dto.ts

import { IsOptional, IsString } from "class-validator";
import { ApiProperty } from "@nestjs/swagger";

export class UpdateWidgetInstanceDto {
  @ApiProperty({ description: "Updated name", required: false })
  @IsOptional()
  @IsString()
  name?: string;

  @ApiProperty({ description: "Updated description", required: false })
  @IsOptional()
  @IsString()
  description?: string;
}
